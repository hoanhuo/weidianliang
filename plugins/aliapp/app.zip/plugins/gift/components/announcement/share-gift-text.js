;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/gift/components/announcement/share-gift-text"],{"2d6b":function(n,t,e){"use strict";var u=e("7bda"),a=e.n(u);a.a},"7bda":function(n,t,e){},9827:function(n,t,e){"use strict";e.r(t);var u=e("f9179"),a=e("fd8b");for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);e("2d6b");var f=e("2877"),i=Object(f["a"])(a["default"],u["a"],u["b"],!1,null,"a3127262",null);t["default"]=i.exports},e2de:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"ready-send",props:["big","small"]};t.default=u},f9179:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},fd8b:function(n,t,e){"use strict";e.r(t);var u=e("e2de"),a=e.n(u);for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);t["default"]=a.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/gift/components/announcement/share-gift-text-create-component',
    {
        'plugins/gift/components/announcement/share-gift-text-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("9827"))
        })
    },
    [['plugins/gift/components/announcement/share-gift-text-create-component']]
]);                
