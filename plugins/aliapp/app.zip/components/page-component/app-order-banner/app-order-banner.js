;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-banner/app-order-banner"],{4474:function(t,n,e){"use strict";e.r(n);var r=e("a61e"),a=e.n(r);for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);n["default"]=a.a},7335:function(t,n,e){},"98e0":function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return a})},a0258:function(t,n,e){"use strict";var r=e("7335"),a=e.n(r);a.a},a61e:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-order-banner",data:function(){return{newPicUrl:""}},props:{title:{type:String,value:""},picUrl:{type:String,value:""},hint:{type:String,value:""}},created:function(){this.newPicUrl=this.$store.state.mallConfig.__wxapp_img.mall.order.status_bar}};n.default=r},ccb8:function(t,n,e){"use strict";e.r(n);var r=e("98e0"),a=e("4474");for(var u in a)"default"!==u&&function(t){e.d(n,t,function(){return a[t]})}(u);e("a0258");var i=e("2877"),c=Object(i["a"])(a["default"],r["a"],r["b"],!1,null,"3dbbc13c",null);n["default"]=c.exports}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-banner/app-order-banner-create-component',
    {
        'components/page-component/app-order-banner/app-order-banner-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("ccb8"))
        })
    },
    [['components/page-component/app-order-banner/app-order-banner-create-component']]
]);                
