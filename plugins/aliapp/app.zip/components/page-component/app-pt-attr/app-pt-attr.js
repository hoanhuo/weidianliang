;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-pt-attr/app-pt-attr"],{"051f":function(t,n,e){"use strict";e.r(n);var r=e("7174"),a=e("5dbd");for(var u in a)"default"!==u&&function(t){e.d(n,t,function(){return a[t]})}(u);e("3e20");var c=e("2877"),i=Object(c["a"])(a["default"],r["a"],r["b"],!1,null,"70f4099a",null);n["default"]=i.exports},"3e20":function(t,n,e){"use strict";var r=e("4a15"),a=e.n(r);a.a},"4a15":function(t,n,e){},"5dbd":function(t,n,e){"use strict";e.r(n);var r=e("e9a6"),a=e.n(r);for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);n["default"]=a.a},7174:function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return a})},e9a6:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-pt-attr",props:{pintuan_groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:String},data:function(){return{}},methods:{active:function(t){this.$emit("click",t)}}};n.default=r}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-pt-attr/app-pt-attr-create-component',
    {
        'components/page-component/app-pt-attr/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("051f"))
        })
    },
    [['components/page-component/app-pt-attr/app-pt-attr-create-component']]
]);                
