;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-pt-attr"],{"27cd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-pt-attr",props:{groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:String},watch:{selectGroupAttrId:{handler:function(t){console.log(t)}}},methods:{active:function(t){this.$emit("click",t)}}};n.default=r},"2b3e":function(t,n,e){},3556:function(t,n,e){"use strict";e.r(n);var r=e("c047"),u=e("6569");for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);e("7e8f");var a=e("2877"),o=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"fed84182",null);n["default"]=o.exports},6569:function(t,n,e){"use strict";e.r(n);var r=e("27cd"),u=e.n(r);for(var c in r)"default"!==c&&function(t){e.d(n,t,function(){return r[t]})}(c);n["default"]=u.a},"7e8f":function(t,n,e){"use strict";var r=e("2b3e"),u=e.n(r);u.a},c047:function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return u})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-pt-attr-create-component',
    {
        'plugins/pt/components/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("3556"))
        })
    },
    [['plugins/pt/components/app-pt-attr-create-component']]
]);                
