(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/pt/components/app-pt-attr"],{"27cd":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"app-pt-attr",props:{groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:String},watch:{selectGroupAttrId:{handler:function(t){console.log(t)}}},methods:{active:function(t){this.$emit("click",t)}}};e.default=r},"2b3e":function(t,e,n){},3556:function(t,e,n){"use strict";n.r(e);var r=n("e52d"),u=n("6569");for(var a in u)"default"!==a&&function(t){n.d(e,t,function(){return u[t]})}(a);n("7e8f");var c=n("2877"),o=Object(c["a"])(u["default"],r["a"],r["b"],!1,null,"fed84182",null);e["default"]=o.exports},6569:function(t,e,n){"use strict";n.r(e);var r=n("27cd"),u=n.n(r);for(var a in r)"default"!==a&&function(t){n.d(e,t,function(){return r[t]})}(a);e["default"]=u.a},"7e8f":function(t,e,n){"use strict";var r=n("2b3e"),u=n.n(r);u.a},e52d:function(t,e,n){"use strict";var r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/pt/components/app-pt-attr-create-component',
    {
        'plugins/pt/components/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("3556"))
        })
    },
    [['plugins/pt/components/app-pt-attr-create-component']]
]);                
