;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-index-nav"],{"2a30":function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return a})},"33db":function(t,n,e){},"387c":function(t,n,e){"use strict";e.r(n);var u=e("bd45d"),a=e.n(u);for(var r in u)"default"!==r&&function(t){e.d(n,t,function(){return u[t]})}(r);n["default"]=a.a},"6bbe":function(t,n,e){"use strict";var u=e("33db"),a=e.n(u);a.a},7136:function(t,n,e){"use strict";e.r(n);var u=e("2a30"),a=e("387c");for(var r in a)"default"!==r&&function(t){e.d(n,t,function(){return a[t]})}(r);e("6bbe");var i=e("2877"),c=Object(i["a"])(a["default"],u["a"],u["b"],!1,null,"06de6ae3",null);n["default"]=c.exports},bd45d:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-index-nav",props:{list:{type:Array,default:function(){return[]}},cat_id:Number,theme:String},data:function(){return{activeIndex:0}},methods:{active:function(t){this.$emit("click",t)}}};n.default=u}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-index-nav-create-component',
    {
        'plugins/pt/components/app-index-nav-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("7136"))
        })
    },
    [['plugins/pt/components/app-index-nav-create-component']]
]);                
