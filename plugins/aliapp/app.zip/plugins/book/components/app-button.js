;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/book/components/app-button"],{"0731":function(n,t,e){"use strict";var u=e("6527"),r=e.n(u);r.a},2306:function(n,t,e){"use strict";e.r(t);var u=e("9e57"),r=e.n(u);for(var a in u)"default"!==a&&function(n){e.d(t,n,function(){return u[n]})}(a);t["default"]=r.a},6527:function(n,t,e){},"9e57":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"app-button"};t.default=u},e1dd:function(n,t,e){"use strict";e.r(t);var u=e("e2cf"),r=e("2306");for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);e("0731");var f=e("2877"),c=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,"9ff84712",null);t["default"]=c.exports},e2cf:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/book/components/app-button-create-component',
    {
        'plugins/book/components/app-button-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("e1dd"))
        })
    },
    [['plugins/book/components/app-button-create-component']]
]);                
