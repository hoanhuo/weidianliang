(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-copyright/app-copyright"],{"1ef7":function(n,t,e){"use strict";var u=e("3dc2"),o=e.n(u);o.a},"33f0":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=function(){return Promise.all([e.e("common/vendor"),e.e("components/basic-component/app-jump-button/app-jump-button")]).then(e.bind(null,"b362"))},o={name:"app-copyright",components:{"app-jump-button":u},props:{backgroundColor:{type:String,default:function(){return"#ff4544"}},link:{type:Object,default:function(){return null}},picUrl:String,text:String}};t.default=o},"3dc2":function(n,t,e){},5989:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},o=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return o})},"7d10":function(n,t,e){"use strict";e.r(t);var u=e("33f0"),o=e.n(u);for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);t["default"]=o.a},"7fe8":function(n,t,e){"use strict";e.r(t);var u=e("5989"),o=e("7d10");for(var r in o)"default"!==r&&function(n){e.d(t,n,function(){return o[n]})}(r);e("1ef7");var c=e("2877"),a=Object(c["a"])(o["default"],u["a"],u["b"],!1,null,"4bf55422",null);t["default"]=a.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-copyright/app-copyright-create-component',
    {
        'components/page-component/app-copyright/app-copyright-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("7fe8"))
        })
    },
    [['components/page-component/app-copyright/app-copyright-create-component']]
]);                
