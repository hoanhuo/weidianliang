(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-order-banner/app-order-banner"],{4474:function(t,n,e){"use strict";e.r(n);var a=e("a61e"),r=e.n(a);for(var u in a)"default"!==u&&function(t){e.d(n,t,function(){return a[t]})}(u);n["default"]=r.a},7335:function(t,n,e){},a0258:function(t,n,e){"use strict";var a=e("7335"),r=e.n(a);r.a},a61e:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-order-banner",data:function(){return{newPicUrl:""}},props:{title:{type:String,value:""},picUrl:{type:String,value:""},hint:{type:String,value:""}},created:function(){this.newPicUrl=this.$store.state.mallConfig.__wxapp_img.mall.order.status_bar}};n.default=a},b6a9:function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return r})},ccb8:function(t,n,e){"use strict";e.r(n);var a=e("b6a9"),r=e("4474");for(var u in r)"default"!==u&&function(t){e.d(n,t,function(){return r[t]})}(u);e("a0258");var i=e("2877"),c=Object(i["a"])(r["default"],a["a"],a["b"],!1,null,"3dbbc13c",null);n["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-order-banner/app-order-banner-create-component',
    {
        'components/page-component/app-order-banner/app-order-banner-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("ccb8"))
        })
    },
    [['components/page-component/app-order-banner/app-order-banner-create-component']]
]);                
