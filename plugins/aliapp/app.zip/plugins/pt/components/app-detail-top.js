;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-detail-top"],{"2e45":function(t,e,n){"use strict";n.r(e);var r=n("fe38"),i=n.n(r);for(var a in r)"default"!==a&&function(t){n.d(e,t,function(){return r[t]})}(a);e["default"]=i.a},"60ce":function(t,e,n){"use strict";n.r(e);var r=n("aafb"),i=n("2e45");for(var a in i)"default"!==a&&function(t){n.d(e,t,function(){return i[t]})}(a);n("8a81");var u=n("2877"),c=Object(u["a"])(i["default"],r["a"],r["b"],!1,null,"3861824e",null);e["default"]=c.exports},"8a81":function(t,e,n){"use strict";var r=n("b3e2"),i=n.n(r);i.a},aafb:function(t,e,n){"use strict";var r=function(){var t=this,e=t.$createElement;t._self._c},i=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})},b3e2:function(t,e,n){},fe38:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"app-detail-top",props:{cover_pic:String,name:String,original_price:String,price:String,people_num:String,status:Number,group_economize_price:String,theme:String}};e.default=r}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-detail-top-create-component',
    {
        'plugins/pt/components/app-detail-top-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("60ce"))
        })
    },
    [['plugins/pt/components/app-detail-top-create-component']]
]);                
